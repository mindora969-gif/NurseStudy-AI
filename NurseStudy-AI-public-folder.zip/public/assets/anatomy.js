
const qs=[
{q:"What is the functional unit of the kidney?",o:["Alveolus","Neuron","Nephron","Osteon"],a:2,e:"The nephron filters blood and modifies filtrate to form urine."},
{q:"Which chamber pumps blood into the systemic circulation?",o:["Right atrium","Right ventricle","Left atrium","Left ventricle"],a:3,e:"The left ventricle ejects blood into the aorta."},
{q:"Where does gas exchange mainly occur in the lungs?",o:["Trachea","Bronchi","Alveoli","Larynx"],a:2,e:"Alveoli provide a large thin surface closely associated with capillaries."},
{q:"Which feedback mechanism counteracts a deviation from a set range?",o:["Positive feedback","Negative feedback","Feed-forward only","No feedback"],a:1,e:"Negative feedback reduces the original change and supports homeostasis."},
{q:"Which blood component is primarily responsible for oxygen transport?",o:["Platelets","Red blood cells","Plasma proteins","Neutrophils"],a:1,e:"Haemoglobin in red blood cells binds and transports most blood oxygen."}
];
const root=document.getElementById("apQuiz");
if(root){root.innerHTML=qs.map((x,i)=>`<div class="question"><b>${i+1}. ${x.q}</b>${x.o.map((v,j)=>`<label><input type="radio" name="aq${i}" value="${j}"> ${v}</label>`).join("")}<div class="feedback" id="af${i}"></div></div>`).join("")+`<button class="btn" id="gradeAP">Check answers</button><p id="ascore"></p>`;document.getElementById("gradeAP").onclick=()=>{let s=0;qs.forEach((x,i)=>{const v=document.querySelector(`input[name=aq${i}]:checked`),f=document.getElementById("af"+i);if(v&&+v.value===x.a){s++;f.textContent="Correct. "+x.e;f.style.color="#16834b"}else{f.textContent="Review: "+x.e;f.style.color="#a44"}});document.getElementById("ascore").textContent=`Score: ${s}/${qs.length}`}}
const search=document.getElementById("topicSearch");if(search){search.addEventListener("input",()=>{const q=search.value.toLowerCase();document.querySelectorAll("main .section").forEach(s=>{s.style.display=!q||s.innerText.toLowerCase().includes(q)?"":"none"})})}
