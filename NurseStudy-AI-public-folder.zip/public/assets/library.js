
const items=[
{q:"Which organelle is the main site of ATP production in most human cells?",o:["Golgi apparatus","Mitochondrion","Lysosome","Ribosome"],a:1,e:"Mitochondria generate most ATP during aerobic cellular respiration."},
{q:"Which tissue type lines body surfaces and cavities?",o:["Epithelial","Muscle","Nervous","Connective"],a:0,e:"Epithelial tissue covers surfaces, lines cavities and forms glands."},
{q:"What is the primary purpose of hand hygiene in patient care?",o:["Improve comfort only","Reduce transmission of microorganisms","Replace PPE","Sterilise the room"],a:1,e:"Hand hygiene is a key measure to reduce healthcare-associated transmission."},
{q:"Which term means maintaining a stable internal environment?",o:["Haemostasis","Homeostasis","Haematopoiesis","Metabolism"],a:1,e:"Homeostasis keeps internal variables within appropriate ranges."}
];
const root=document.getElementById("quizbox");
if(root){root.innerHTML=items.map((x,i)=>`<div class="question"><b>${i+1}. ${x.q}</b>${x.o.map((v,j)=>`<label><input type="radio" name="lq${i}" value="${j}"> ${v}</label>`).join("")}<div id="lf${i}" class="feedback"></div></div>`).join("")+`<button class="btn" id="gradeLibrary">Check answers</button><p id="lscore"></p>`;document.getElementById("gradeLibrary").onclick=()=>{let s=0;items.forEach((x,i)=>{let v=document.querySelector(`input[name=lq${i}]:checked`);let f=document.getElementById("lf"+i);if(v&&+v.value===x.a){s++;f.textContent="Correct. "+x.e;f.style.color="#16834b"}else{f.textContent="Review: "+x.e;f.style.color="#a44"}});document.getElementById("lscore").textContent=`Score: ${s}/${items.length}`}}
